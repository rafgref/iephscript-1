
<?php

 $error = false;
 
if (isset($_POST['user'])) {
  $username = trim($_POST['user']);
  $username = strip_tags($username);
  $username = htmlspecialchars($username);
  
  $password1 = trim($_POST['password']);
  $password1 = strip_tags($password1);
  $password1 = htmlspecialchars($password1);
 
  $cpassword = $_POST['confirmpassword'];
  $cpassword = strip_tags($cpassword);
  $cpassword = htmlspecialchars($cpassword);
  

	$password1 = $_POST['password'];
	$nDays = $_POST['dates'];
	$datess = date('m/d/y', strtotime('+'.$nDays.' days'));
	$password = escapeshellarg( crypt($password1) );
     
	   
   if (empty($username)) {
   $error = true;
   $nameError = "Please enter your username.";
  } else if (strlen($username) < 3) {
   $error = true;
   $nameError = "Name must have atleat 3 characters.";
  }
  
   if (empty($password1)){
   $error = true;
   $passError = "Please enter password.";
  } else if(strlen($password1) < 3) {
   $error = true;
   $passError = "Password must have atleast 3 characters.";
  }
  
  if($password1 != $cpassword){
	 $error = true;
   $cpaseror = "Password Didn't match.";
  } 

  

   if( !$error ) {
date_default_timezone_set('UTC');
date_default_timezone_set("Asia/Manila"); 
$my_date = date("Y-m-d H:i:s");
	   
	   
$hosts= 'ip ng vps mo';
$connection = ssh2_connect($hosts, 22);
if (ssh2_auth_password($connection, 'root', 'pass ng vps mo')) {

	
$show = true;
	
	 
ssh2_exec($connection, "useradd $username -m -p $password -e $datess -d  /home/$username -s /bin/false");
  
            $succ = 'Added Succesfully';
			
	
   if ($res) {
    $errTyp = "success";
    $errMSG = "Successfully registered, you may Check your credentials";
    $username = '';
    $password = '';
    $cpassword = '';
	
   } else {
    $errTyp = "danger";
    $errMSG = "Something went wrong, try again later..."; 
   } 

} else {
        die('Connection Failed...');
}	
	 }   
  } 

   



?>


﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>IEPHSSH BEST SSH</title>
    <link rel="shortcut icon" type="image/x-icon" href="https://preview.ibb.co/kvjc7J/Pics_Art_06_30_01_33_27.png">
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="/asset/phcraf/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME ICONS  -->
    <link href="/asset/phcraf/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="/asset/phcraf/css/style.css" rel="stylesheet" />
     <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <center><strong>Email: </strong>info@yourdomain.com
                    <br>&nbsp;
                    <strong>Support: </strong>+90-897-678-44</center>
                </div>

            </div>
        </div>
    </header>
    <!-- HEADER END-->
    <div class="navbar navbar-inverse set-radius-zero">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">

                    <img src="https://image.ibb.co/mjegPT/1532750065543.png" height="50" width="140" />
                </a>

            </div>

            <div class="left-div">
                <div class="user-settings-wrapper">
                    <ul class="nav">

                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                                <span class="glyphicon glyphicon-user" style="font-size: 25px;"></span>
                            </a>
                            <div class="dropdown-menu dropdown-settings">
                                <div class="media">
                                    <a class="media-left" href="#">
                                        <img src="https://preview.ibb.co/kvjc7J/Pics_Art_06_30_01_33_27.png" height="60" width="60" alt="" class="img-rounded" />
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading">IEPH DEVELOPERS </h4>
                                        <h5>Developer & Designer</h5>

                                    </div>
                                </div>
                                <hr />
                                <h5><strong>Personal Bio : </strong></h5>
                                We are IEPH DEVELOPERS we are solid team in phc
                                <hr />
                                <a href="#" class="btn btn-info btn-sm">Full Profile</a>

                            </div>
                        </li>


                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
    <section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a class="menu-top-active" href="/index.html">Dashboard</a></li>
                            <li><a href="/ssh.html">SSH</a></li>
<li><a href="http://www.httptunnel.ge/ProxyListForFree.aspx">squid proxy</a></li>
<li><a href="http://www.httptunnel.ge/ProxyChecker.aspx">proxy checker</a></li>
                            <li><a href="https://ping.eu/ping/">ping checker</a></li>
                            <li><a href="/speed.html">speed test</a></li>
                             <li><a href="https://www.facebook.com/groups/790361371158062/">Join to community</a></li>
                            

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="page-head-line"><a href="/index.html">Dashboard</a> > SSH 1</h4>

                </div>

            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-success">
                        <h1><center>SSH</h1></center>
                        <center>Thank you for coming in our ssh site</center>
                    </div>
                </div>

            </div>
            
           

                    <hr />
                <div class="row">
                 <div class="col-md-6">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           <center><h4>SERVER1</h4></center>
                        </div>
                        <div class="panel-body">
                          <form method="post" action=" server1.php" autocomplete="off">
						<div class="form-group"><?php echo  $succ; ?></div>
												<div class="form-group">
							<label for="username" class="cols-sm-2 control-label">Username</label>
							
							<div class="cols-sm-10">
							<span class="text-danger"><?php echo $nameError; ?></span>
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="user" id="username"  placeholder="Enter your Username" value="<?php echo $username ?>"/>
									
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="password" class="cols-sm-2 control-label">Password</label>
							<div class="cols-sm-10">
							<span class="text-danger"><?php echo $passError; ?></span>
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
									<input type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password"  value="<?php echo $password1 ?>" />
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="confirm" class="cols-sm-2 control-label">Confirm Password</label>
							<div class="cols-sm-10">
							<span class="text-danger"><?php echo $cpaseror; ?></span>
						
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
									<input type="password" class="form-control" name="confirmpassword" id="confirm"  placeholder="Confirm your Password"/>
								</div>
							</div>
						</div>
						<div class="form-group" >
						<label> Select Number of Days : 
<select name="dates" id="selects">    
   <option value="3">3</option>
    <option value="5">5</option>
	 <option value="7">7</option>

 </select></label>
 </div>
						<div class="form-group ">
							<input type="submit" id="button" class="btn btn-primary btn-lg btn-block login-button" value="Register"><br />
							
						</div>
						<div class="form-group ">
						<Center>
						
						</center>
						<?php
						
						if($show == true) {
							echo "<Center>"; echo 'Account Details :'; echo "</Center>"; echo "<br />";
						 
						echo 'Host : 206.189.90.169'; echo "<br />";
						 echo 'Username :'; echo $username; echo "<br />";
						 echo 'Password :'; echo $password1; echo "<br />";
						 echo 'Port : 22,443'; echo "<br />";
						 echo 'Squid : 80,8000,8080,3128'; echo "<br />";
						 echo 'Day :'; echo $nDays; echo "<br />";
						 echo 'Date Expired :'; echo $datess; echo "<br />";
						}
						?>
                                       
 
                                          
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                  </ hr>                               <div class="text-center alert alert-warning">
                        <a href="https://www.facebook.com/groups/790361371158062/" class="btn btn-social btn-facebook">
                            <i class="fa fa-facebook"></i>&nbsp; Facebook</a>
                        <a href="#" class="btn btn-social btn-google">
                            <i class="fa fa-google-plus"></i>&nbsp; Google</a>
                        <a href="#" class="btn btn-social btn-twitter">
                            <i class="fa fa-twitter"></i>&nbsp; Twitter </a>
                        <a href="#" class="btn btn-social btn-linkedin">
                            <i class="fa fa-linkedin"></i>&nbsp; Linkedin </a>
                    </div></div>
        </div></div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <center>&copy; 2018 IEPH | Design By : <a href="https://www.phcorner.net/members/1124227/" target="_blank"><font color="#0000FF">PHC-Raf</font></a></center>
                </div>

            </div>
        </div>
        </div>
        
    </footer>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="/asset/phcraf/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="/asset/phcraf/js/bootstrap.js"></script>
</body>
</html>
